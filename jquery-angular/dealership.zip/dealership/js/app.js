(function() {
	"use strict";

	console.log("go app go");

	// this creates your angular app.  the empty brackets are a set of depencencies.
	// we have no dependencies, but things like ngRoute could go here.

	// the name 'dealershipApp' is arbitrary but you'll see it later.
	angular.module("dealershipApp", []);
}());